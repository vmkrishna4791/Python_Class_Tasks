import mysql.connector as connection

class MYSQLDBCONN:
    def __init__(self, host, db, user, password):

        self.host = host
        self.db = db
        self.user = user
        self.password = password

    def conn_module(self):
        DB = connection.connect(host=self.host, database=self.db, user=self.user, passwd=self.password, use_pure=True)
        #print("database connected:",mydb.is_connected())
        return(DB)