import logging

def logger_func(log):
    logging.basicConfig(filename="db_log.log", level=logging.DEBUG, format='%(asctime)s %(message)s')
    logging.info(log)

