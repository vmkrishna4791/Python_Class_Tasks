from flask import Flask, render_template, request, jsonify
from flask.views import View
from flask.views import MethodView
import csv
import os
import log
import mysqldbconnect as db_conn


app = Flask('__name__')

class CreateTable(View):


    def dispatch_request(self):
        if (request.method == 'POST'):
            hostname = request.json['hostname']
            db_name = request.json['db_name']
            login = request.json['login']
            password = request.json['passwd']
            table_name = request.json['table_name']
            columns_type = request.json['columns_type']
            #print(hostname, columns_type, db_name, login, password, table_name)

            # print(table_name)

            result = db_name + " , " + login + " , " + password + " , " + table_name
            log.logger_func(result)

            for cols, cols_type in columns_type.items():
                #print(cols, cols_type)
                result = result + " , " + cols + " : " + cols_type

            try:
                db_instance = db_conn.MYSQLDBCONN('localhost', 'student', 'root', 'mysql')
                mydb = db_instance.conn_module()
                #print(mydb)
                print("database connected:", mydb.is_connected())
                log.logger_func("database connected:" + str(mydb.is_connected()))
                mycursor = mydb.cursor()

                mycursor.execute("show tables")
                myresult = mycursor.fetchall()
                #    print(myresult)

                for tabname in myresult:
                    print(tabname[0])
                    if (str(tabname[0]) == table_name):
                        query = "drop table " + table_name
                        print(query)
                        mycursor.execute(query)

                result = 'create table ' + table_name + ' ('

                for cols, cols_type, in columns_type.items():
                   # print(cols, cols_type)
                    result = result + cols + " " + cols_type + ", "

                result = result.rstrip(', ')
                #   print(result)
                result = result + ")"
                #print(result)
                query = result
                #print(query)
                mycursor.execute(query)

                result = '\'' + table_name + '\'' + "Table created in database " + db_name

                mydb.close()
                print(result)
                log.logger_func(result)
                return jsonify(result)



            except Exception as e:
                mydb.close()
                print(str(e))
                log.logger_func(str(e))
                return jsonify(str(e))



app.add_url_rule('/createtable', view_func=CreateTable.as_view('createtable'), methods=['POST'])




#######Single Insert into a table############

class InsertTable(View):


    def dispatch_request(self):
        if (request.method == 'POST'):
            hostname = request.json['hostname']
            db_name = request.json['db_name']
            login = request.json['login']
            password = request.json['passwd']
            table_name = request.json['table_name']
            columns_val = request.json['columns_val']

            print(hostname, columns_val, db_name, login, password, table_name)

            print("Current working directory:", os.getcwd())
            log.logger_func("Current working directory: " + os.getcwd())

            log.logger_func(
                "Parameters for making a mysql db connection: hostname: {0}, dbname: {1}, login: {2}, passwd : {3}" \
                .format(hostname, db_name, login, password))

            try:
                db_instance = db_conn.MYSQLDBCONN('localhost', 'student', 'root', 'mysql')
                mydb = db_instance.conn_module()
                print("database connected:", mydb.is_connected())
                log.logger_func("database connected:" + str(mydb.is_connected()))

                mycursor = mydb.cursor()
                mycursor.execute("show tables")
                myresult = mycursor.fetchall()
                #  print(myresult)

                log.logger_func("Tables in the database: " + db_name + ": " + str(myresult))

                temp_data = []

                stm1 = 'insert into ' + table_name + ' values({rec})'

                for cols, cols_val, in columns_val.items():
                    # print(cols, cols_val)
                    temp_data.append(cols_val)

                record = ','.join([f"'{str(elem)}'" for elem in temp_data])
                # print(record)

                mycursor.execute(stm1.format(rec=','.join([f"'{str(elem)}'" for elem in temp_data])))
                mydb.commit()
                print("Succefully Inserted the record: " + record)
                log.logger_func("Succefully Inserted the record: " + record)

                result = "Inserted into database : " + db_name + ", table: " + '\'' + table_name + '\'' + 'values:' + record

                mydb.close()

                log.logger_func("database connected:" + str(mydb.is_connected()))
                return jsonify(result)


            except Exception as e:
                mydb.close()
                print(str(e))
                log.logger_func(str(e))
                log.logger_func("database connected:" + str(mydb.is_connected()))
                return jsonify(str(e))


app.add_url_rule('/inserttable', view_func=InsertTable.as_view('inserttable'), methods=['POST'])


######## Bulk inserts through a csv file###########

class BulkInsertTable(View):

    def dispatch_request(self):
        if (request.method == 'POST'):
            hostname= request.json['hostname']
            db_name = request.json['db_name']
            login = request.json['login']
            password = request.json['passwd']
            table_name = request.json['table_name']
            csv_file = request.json['input_file']
            #print("CSV_File:",csv_file)

            print("Current working directory:", os.getcwd())

            log.logger_func("Current working directory: " + os.getcwd())

            log.logger_func(
                "Parameters for making a mysql db connection: hostname: {0}, dbname: {1}, login: {2}, passwd : {3}" \
                .format(hostname, db_name, login, password))


            try:
                db_instance = db_conn.MYSQLDBCONN('localhost', 'student', 'root', 'mysql')
                mydb = db_instance.conn_module()
                print("database connected:", mydb.is_connected())
                log.logger_func("database connected:" + str(mydb.is_connected()))
                mycursor = mydb.cursor()

                mycursor.execute("show tables")
                myresult = mycursor.fetchall()

                stm1 = 'insert into ' + table_name + ' values({rec})'

                count_successful_records = 0
                count_failed_records = 0

                with open('empdata.csv', "r") as data:
                    next(data)
                    data_csv = csv.reader(data, delimiter='\n')
                    #print('data_csv:', data_csv)

                    for i in (data_csv):
                        try:
                            val = str(i[0]).split(',')
                       #     print("string value:", val)

                            mycursor.execute(stm1.format(rec=','.join([f"'{str(elem)}'" for elem in val])))

                            print("Succesfully entered record in table: {0}, record: {1}".format(table_name, val))


                            log.logger_func("Succesfully inserted values in table"+str(table_name)+str(val))
                            count_successful_records = count_successful_records+1
                            #print(count_successful_records)


                        except Exception as e:
                            print(str(e))
                            log.logger_func(str(e))
                            count_failed_records = count_failed_records+1



                    mydb.commit()

                print("Successfully  Inserted Record Number:",count_successful_records)
                print("Failed Insert Record Number:",count_failed_records)

                result = "Number of  records inserted into table: {0} is {1}. Failed number of records is {2}".format(table_name, count_successful_records, count_failed_records)

                mydb.close()
                log.logger_func("database connected:" + str(mydb.is_connected()))
                log.logger_func("Number of  records successfully inserted into table: {0} is {1}. Failed number of records is {2}".format(table_name, count_successful_records, count_failed_records))
                return jsonify(result)



            except Exception as e:
                log.logger_func(str(e))
                mydb.close()
                return jsonify(str(e))


app.add_url_rule('/bulkinserttable', view_func=BulkInsertTable.as_view('bulkinserttable'), methods=['POST'])


########Deleting an entry from a table#######

class DeleteFromTable(View):

    def dispatch_request(self):
        if (request.method == 'POST'):
            hostname = request.json['hostname']
            db_name = request.json['db_name']
            login = request.json['login']
            password = request.json['passwd']
            table_name = request.json['table_name']
            columns_val = request.json['columns_val']

            print("Current working directory:", os.getcwd())

            log.logger_func("Current working directory: " + os.getcwd())

            log.logger_func(
                "Parameters for making a mysql db connection: hostname: {0}, dbname: {1}, login: {2}, passwd : {3}" \
                    .format(hostname, db_name, login, password))


            result = ""

            for cols, cols_val in columns_val.items():
               # print(cols, cols_val)
                result = result + str(cols) + "=" + '\'' + str(cols_val) + '\'' + " and "
               # print(result)

            result = result.rstrip(' and ')
            #print("result:", result, type(result))

            try:
                db_instance = db_conn.MYSQLDBCONN('localhost', 'student', 'root', 'mysql')
                mydb = db_instance.conn_module()
                print("database connected:", mydb.is_connected())
                log.logger_func("database connected:" + str(mydb.is_connected()))
                mycursor = mydb.cursor()

                query = 'delete from  {0} where {1}'.format(table_name, result)

                #print("query:", query)

                mycursor.execute(query)
                mydb.commit()

                result = "Deleted entries from database : " + db_name + ", table: " + '\'' + table_name + '\'' + 'values:' + result
                print(result)

                log.logger_func(result)
                mydb.close()
                return jsonify(result)



            except Exception as e:
                mydb.close()
                print(str(e))
                log.logger_func(str(e))
                return jsonify(str(e))



app.add_url_rule('/deletefromtable', view_func=DeleteFromTable.as_view('deletefromtable'), methods=['POST'])


#########Update a table#########

class UpdateTable(View):

    def dispatch_request(self):
        if (request.method == 'POST'):
            hostname = request.json['hostname']
            db_name = request.json['db_name']
            login = request.json['login']
            password = request.json['passwd']
            table_name = request.json['table_name']
            columns_val = request.json['columns_val']
            row_val = request.json['map_val']

            print(hostname, columns_val, db_name, login, password, table_name, row_val)

            print("Current working directory:", os.getcwd())

            log.logger_func("Current working directory: " + os.getcwd())

            log.logger_func(
                "Parameters for making a mysql db connection: hostname: {0}, dbname: {1}, login: {2}, passwd : {3}" \
                    .format(hostname, db_name, login, password))

            result = ""

            for cols, cols_val in columns_val.items():
                #print(cols, cols_val)
                result = result + str(cols) + "=" + '\'' + str(cols_val) + '\'' + ", "
                #print(result)

            result = result.rstrip(', ')
            #print("result:", result, type(result))

            update_criterion = ""
            for key, value in row_val.items():
                update_criterion = update_criterion + str(key) + "=" + str(value) + " and "

            update_criterion = update_criterion.rstrip(' and ')

            print("Update_criterion:", update_criterion)

            try:
                db_instance = db_conn.MYSQLDBCONN('localhost', 'student', 'root', 'mysql')
                mydb = db_instance.conn_module()
                print("database connected:", mydb.is_connected())
                log.logger_func("database connected:" + str(mydb.is_connected()))

                mycursor = mydb.cursor()

                #  mycursor.execute("show tables")
                #  myresult = mycursor.fetchall()
                #  print(myresult)

                query = 'update {0} set {1} where {2}'.format(table_name, result, update_criterion)

                #print("query:", query)

                outcome = mycursor.execute(query)
                print(outcome)
                mydb.commit()

                result = 'Updated entries into database: {0} , table: {1}, where the {2}, values set to {3}'.format(
                    db_name, table_name,
                    update_criterion, result)

                print(result)
                log.logger_func(result)

                mydb.close()
                return jsonify(result)


            except Exception as e:
                mydb.close()
                print(str(e))
                log.logger_func(str(e))
                return jsonify(str(e))


app.add_url_rule('/updatetable', view_func=UpdateTable.as_view('updatetable'), methods=['POST'])

###### Download data from a table #########

class ImportTableToFile(View):


    def dispatch_request(self):
        if (request.method == 'POST'):
            hostname = request.json['hostname']
            db_name = request.json['db_name']
            login = request.json['login']
            password = request.json['passwd']
            table_name = request.json['table_name']
            #output_file = request.json['output_file']

            #print(hostname, db_name, login, password, table_name, output_file)

            cwd = os.getcwd()
            print("Current working directory:", os.getcwd())
            print("Current working directory:", os.getcwd())

            log.logger_func("Current working directory: " + os.getcwd())

            log.logger_func(
                "Parameters for making a mysql db connection: hostname: {0}, dbname: {1}, login: {2}, passwd : {3}" \
                    .format(hostname, db_name, login, password))

            #   print(table_name)

            try:
                db_instance = db_conn.MYSQLDBCONN('localhost', 'student', 'root', 'mysql')
                mydb = db_instance.conn_module()
                print("database connected:", mydb.is_connected())
                log.logger_func("database connected:" + str(mydb.is_connected()))

                mycursor = mydb.cursor()

                query = 'select * from {0}'.format(table_name)
                #print(query)
                mycursor.execute(query)
                result = mycursor.fetchall()


                with open('output_file.csv', "w", newline='') as data:
                    writehandler = csv.writer(data)
                    writehandler.writerow([i[0] for i in mycursor.description])  # write column names into the output file
                    writehandler.writerows(result)

                result = "Reading data from database " + db_name + ", table: " + '\'' + table_name + '\'' \
                         + "into  output_file.csv in the current directory : " + cwd

                print(result)
                log.logger_func(result)

                mydb.close()
                return jsonify(result)



            except Exception as e:
                mydb.close()
                print(str(e))
                log.logger_func(str(e))
                return jsonify(str(e))

app.add_url_rule('/importtabletofile', view_func=ImportTableToFile.as_view('importtabletofile'), methods=['POST'])

if __name__ == '__main__':
    app.run()